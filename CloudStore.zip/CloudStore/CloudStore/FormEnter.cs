namespace CloudStore
{
    public partial class FormEnter : Form
    {
        public FormEnter()
        {
            InitializeComponent();
            labelIncorrect.Hide();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void linkLabelReg_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();
            new FormReg().Show();
        }

        private void buttonEnter_Click(object sender, EventArgs e)
        {
            if ((textBoxLogin.Text == profile.login)^(textBoxPassword.Text==profile.password))
            {
                this.Hide();
                new FormMain().Show();
            }
            else 
            {
                this.labelIncorrect.Show();
            }
        }
    }
}
