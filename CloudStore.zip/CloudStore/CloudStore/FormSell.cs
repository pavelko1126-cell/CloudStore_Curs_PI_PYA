﻿namespace CloudStore
{
    public partial class FormSell : Form
    {
        public FormSell()
        {
            InitializeComponent();
            foreach (product pr in FormMain.products)
            {
                comboBoxName.Items.Add(pr.name);
            }

        }

        private void comboBoxName_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBoxName.Items.Count > 0)
            {

                for (int i = 0; i < FormMain.products.Count; i++)
                {
                    if (i == comboBoxName.SelectedIndex)
                    {
                        textBoxCost.Text = Convert.ToString(FormMain.products[i].price);
                        textBoxAmount.Text = Convert.ToString(FormMain.products[i].amount);
                        textBoxPricecost.Text = Convert.ToString(FormMain.products[i].costprice);
                        textBoxSum.Text = Convert.ToString(Convert.ToInt32(textBoxSellAmount.Text) * Convert.ToInt32(textBoxCost.Text));
                        textBoxSumDiscount.Text = Convert.ToString(Convert.ToInt32(textBoxSum.Text) * Convert.ToInt32(textBoxDiscount.Text) / 100);
                        textBoxSumAfter.Text = Convert.ToString(Convert.ToInt32(textBoxSum.Text) - Convert.ToInt32(textBoxSumDiscount.Text));
                        break;
                    }
                }
            }
        }

        private void textBoxSellAmount_TextChanged(object sender, EventArgs e)
        {
            try
            {
                Convert.ToInt32(textBoxSellAmount.Text);
            }
            catch
            {
                textBoxSellAmount.Undo();
                textBoxSellAmount.ClearUndo();
            }
            finally
            {
                if (Convert.ToInt32(textBoxSellAmount.Text) >= Convert.ToInt32(textBoxAmount.Text))
                {
                    textBoxSellAmount.Text = textBoxAmount.Text;
                }
                textBoxSum.Text = Convert.ToString(Convert.ToInt32(textBoxSellAmount.Text) * Convert.ToInt32(textBoxCost.Text));
                textBoxSumDiscount.Text = Convert.ToString(Convert.ToInt32(textBoxSum.Text) * Convert.ToInt32(textBoxDiscount.Text) / 100);
                textBoxSumAfter.Text = Convert.ToString(Convert.ToInt32(textBoxSum.Text) - Convert.ToInt32(textBoxSumDiscount.Text));
            }
        }

        private void textBoxDiscount_TextChanged(object sender, EventArgs e)
        {
            try
            {
                Convert.ToInt32(textBoxDiscount.Text);
            }
            catch
            {
                textBoxDiscount.Undo();
                textBoxDiscount.ClearUndo();
            }
            finally
            {
                if (Convert.ToInt32(textBoxDiscount.Text) >= 100)
                {
                    textBoxDiscount.Text = "100";
                }
                textBoxSum.Text = Convert.ToString(Convert.ToInt32(textBoxSellAmount.Text) * Convert.ToInt32(textBoxCost.Text));
                textBoxSumDiscount.Text = Convert.ToString(Convert.ToInt32(textBoxSum.Text) * Convert.ToInt32(textBoxDiscount.Text) / 100);
                textBoxSumAfter.Text = Convert.ToString(Convert.ToInt32(textBoxSum.Text) - Convert.ToInt32(textBoxSumDiscount.Text));
            }
        }

        private void buttonCancel_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void buttonSell_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < FormMain.products.Count; i++)
            {
                if (i == comboBoxName.SelectedIndex)
                {
                    if (FormMain.products[i].amount != Convert.ToInt32(textBoxSellAmount.Text))
                    {
                        FormMain.products[i].amount = Convert.ToInt32(Convert.ToInt32(textBoxAmount.Text) - Convert.ToInt32(textBoxSellAmount.Text));
                    }
                    else
                    {
                        FormMain.products.RemoveAt(i);
                        FormMain.listViewProducts.Items.RemoveAt(i);
                    }
                }
            }
            Close();
        }
    }
}
