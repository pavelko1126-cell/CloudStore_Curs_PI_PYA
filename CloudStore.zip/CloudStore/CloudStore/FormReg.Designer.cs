﻿namespace CloudStore
{
    partial class FormReg
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            buttonEnter = new Button();
            textBoxName = new TextBox();
            label3 = new Label();
            textBoxMail = new TextBox();
            label2 = new Label();
            label1 = new Label();
            textBoxSurname = new TextBox();
            label4 = new Label();
            textBoxLogin = new TextBox();
            label5 = new Label();
            textBoxPassword = new TextBox();
            label6 = new Label();
            SuspendLayout();
            // 
            // buttonEnter
            // 
            buttonEnter.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 204);
            buttonEnter.Location = new Point(108, 386);
            buttonEnter.Name = "buttonEnter";
            buttonEnter.Size = new Size(176, 35);
            buttonEnter.TabIndex = 12;
            buttonEnter.Text = "Регистрация";
            buttonEnter.UseVisualStyleBackColor = true;
            buttonEnter.Click += buttonEnter_Click;
            // 
            // textBoxName
            // 
            textBoxName.Location = new Point(12, 123);
            textBoxName.Name = "textBoxName";
            textBoxName.Size = new Size(368, 23);
            textBoxName.TabIndex = 11;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(12, 105);
            label3.Name = "label3";
            label3.Size = new Size(31, 15);
            label3.TabIndex = 10;
            label3.Text = "Имя";
            // 
            // textBoxMail
            // 
            textBoxMail.Location = new Point(12, 59);
            textBoxMail.Name = "textBoxMail";
            textBoxMail.Size = new Size(368, 23);
            textBoxMail.TabIndex = 9;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(12, 41);
            label2.Name = "label2";
            label2.Size = new Size(113, 15);
            label2.TabIndex = 8;
            label2.Text = "Электронная почта";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Arial", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 204);
            label1.Location = new Point(123, 9);
            label1.Name = "label1";
            label1.Size = new Size(132, 24);
            label1.TabIndex = 7;
            label1.Text = "Регистрация";
            label1.Click += label1_Click;
            // 
            // textBoxSurname
            // 
            textBoxSurname.Location = new Point(12, 189);
            textBoxSurname.Name = "textBoxSurname";
            textBoxSurname.Size = new Size(368, 23);
            textBoxSurname.TabIndex = 15;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(12, 171);
            label4.Name = "label4";
            label4.Size = new Size(58, 15);
            label4.TabIndex = 14;
            label4.Text = "Фамилия";
            label4.Click += label4_Click;
            // 
            // textBoxLogin
            // 
            textBoxLogin.Location = new Point(12, 257);
            textBoxLogin.Name = "textBoxLogin";
            textBoxLogin.Size = new Size(368, 23);
            textBoxLogin.TabIndex = 17;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(12, 239);
            label5.Name = "label5";
            label5.Size = new Size(93, 15);
            label5.TabIndex = 16;
            label5.Text = "Создайте логин";
            // 
            // textBoxPassword
            // 
            textBoxPassword.Location = new Point(12, 329);
            textBoxPassword.Name = "textBoxPassword";
            textBoxPassword.Size = new Size(368, 23);
            textBoxPassword.TabIndex = 19;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(12, 311);
            label6.Name = "label6";
            label6.Size = new Size(100, 15);
            label6.TabIndex = 18;
            label6.Text = "Создайте пароль";
            // 
            // FormReg
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(407, 428);
            Controls.Add(textBoxPassword);
            Controls.Add(label6);
            Controls.Add(textBoxLogin);
            Controls.Add(label5);
            Controls.Add(textBoxSurname);
            Controls.Add(label4);
            Controls.Add(buttonEnter);
            Controls.Add(textBoxName);
            Controls.Add(label3);
            Controls.Add(textBoxMail);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "FormReg";
            Text = "CloudStore: Регистрация";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Button buttonEnter;
        private TextBox textBoxName;
        private Label label3;
        private TextBox textBoxMail;
        private Label label2;
        private Label label1;
        private TextBox textBoxSurname;
        private Label label4;
        private TextBox textBoxLogin;
        private Label label5;
        private TextBox textBoxPassword;
        private Label label6;
    }
}