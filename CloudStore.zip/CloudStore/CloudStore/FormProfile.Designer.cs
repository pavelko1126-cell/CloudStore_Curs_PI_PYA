﻿namespace CloudStore
{
    partial class FormProfile
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            textBoxEmail = new TextBox();
            textBoxSurname = new TextBox();
            textBoxName = new TextBox();
            textBoxLogin = new TextBox();
            buttonPChange = new Button();
            buttonExit = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(12, 21);
            label1.Name = "label1";
            label1.Size = new Size(31, 15);
            label1.TabIndex = 0;
            label1.Text = "Имя";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(12, 60);
            label2.Name = "label2";
            label2.Size = new Size(58, 15);
            label2.TabIndex = 1;
            label2.Text = "Фамилия";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(12, 104);
            label3.Name = "label3";
            label3.Size = new Size(113, 15);
            label3.TabIndex = 2;
            label3.Text = "Электронная почта";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(12, 153);
            label4.Name = "label4";
            label4.Size = new Size(41, 15);
            label4.TabIndex = 3;
            label4.Text = "Логин";
            // 
            // textBoxEmail
            // 
            textBoxEmail.Location = new Point(140, 96);
            textBoxEmail.Name = "textBoxEmail";
            textBoxEmail.ReadOnly = true;
            textBoxEmail.Size = new Size(100, 23);
            textBoxEmail.TabIndex = 4;
            // 
            // textBoxSurname
            // 
            textBoxSurname.Location = new Point(140, 52);
            textBoxSurname.Name = "textBoxSurname";
            textBoxSurname.ReadOnly = true;
            textBoxSurname.Size = new Size(100, 23);
            textBoxSurname.TabIndex = 5;
            // 
            // textBoxName
            // 
            textBoxName.Location = new Point(140, 13);
            textBoxName.Name = "textBoxName";
            textBoxName.ReadOnly = true;
            textBoxName.Size = new Size(100, 23);
            textBoxName.TabIndex = 6;
            // 
            // textBoxLogin
            // 
            textBoxLogin.Location = new Point(140, 145);
            textBoxLogin.Name = "textBoxLogin";
            textBoxLogin.ReadOnly = true;
            textBoxLogin.Size = new Size(100, 23);
            textBoxLogin.TabIndex = 7;
            // 
            // buttonPChange
            // 
            buttonPChange.Location = new Point(12, 193);
            buttonPChange.Name = "buttonPChange";
            buttonPChange.Size = new Size(228, 28);
            buttonPChange.TabIndex = 9;
            buttonPChange.Text = "Поменять пароль";
            buttonPChange.UseVisualStyleBackColor = true;
            buttonPChange.Click += buttonPChange_Click;
            // 
            // buttonExit
            // 
            buttonExit.Location = new Point(12, 239);
            buttonExit.Name = "buttonExit";
            buttonExit.Size = new Size(228, 28);
            buttonExit.TabIndex = 10;
            buttonExit.Text = "Выйти";
            buttonExit.UseVisualStyleBackColor = true;
            buttonExit.Click += buttonExit_Click;
            // 
            // FormProfile
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(261, 288);
            Controls.Add(buttonExit);
            Controls.Add(buttonPChange);
            Controls.Add(textBoxLogin);
            Controls.Add(textBoxName);
            Controls.Add(textBoxSurname);
            Controls.Add(textBoxEmail);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "FormProfile";
            Text = "CloudStore: Профиль";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private TextBox textBoxEmail;
        private TextBox textBoxSurname;
        private TextBox textBoxName;
        private TextBox textBoxLogin;
        private Button buttonPChange;
        private Button buttonExit;
    }
}