﻿namespace CloudStore
{
    partial class FormAdd
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            buttonAdd = new Button();
            buttonCancel = new Button();
            textBoxSum = new TextBox();
            textBoxPricecost = new TextBox();
            textBoxAmount = new TextBox();
            textBoxName = new TextBox();
            textBoxCost = new TextBox();
            label6 = new Label();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Arial", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 204);
            label1.Location = new Point(111, 9);
            label1.Name = "label1";
            label1.Size = new Size(165, 24);
            label1.TabIndex = 8;
            label1.Text = "Добавить товар";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(12, 42);
            label2.Name = "label2";
            label2.Size = new Size(90, 15);
            label2.TabIndex = 9;
            label2.Text = "Наименование";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(12, 143);
            label3.Name = "label3";
            label3.Size = new Size(103, 15);
            label3.TabIndex = 10;
            label3.Text = "Суммарная цена:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(220, 107);
            label4.Name = "label4";
            label4.Size = new Size(84, 15);
            label4.TabIndex = 11;
            label4.Text = "Цена закупки:";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(12, 102);
            label5.Name = "label5";
            label5.Size = new Size(75, 15);
            label5.TabIndex = 12;
            label5.Text = "Количество:";
            // 
            // buttonAdd
            // 
            buttonAdd.Location = new Point(121, 179);
            buttonAdd.Name = "buttonAdd";
            buttonAdd.Size = new Size(118, 23);
            buttonAdd.TabIndex = 13;
            buttonAdd.Text = "Добавить";
            buttonAdd.UseVisualStyleBackColor = true;
            buttonAdd.Click += buttonAdd_Click;
            // 
            // buttonCancel
            // 
            buttonCancel.Location = new Point(12, 179);
            buttonCancel.Name = "buttonCancel";
            buttonCancel.Size = new Size(75, 23);
            buttonCancel.TabIndex = 14;
            buttonCancel.Text = "Отменить";
            buttonCancel.UseVisualStyleBackColor = true;
            buttonCancel.Click += buttonCancel_Click;
            // 
            // textBoxSum
            // 
            textBoxSum.Location = new Point(121, 140);
            textBoxSum.Name = "textBoxSum";
            textBoxSum.ReadOnly = true;
            textBoxSum.Size = new Size(138, 23);
            textBoxSum.TabIndex = 15;
            textBoxSum.Text = "0";
            // 
            // textBoxPricecost
            // 
            textBoxPricecost.Location = new Point(310, 104);
            textBoxPricecost.Name = "textBoxPricecost";
            textBoxPricecost.Size = new Size(100, 23);
            textBoxPricecost.TabIndex = 16;
            textBoxPricecost.Text = "0";
            textBoxPricecost.TextChanged += textBoxPricecost_TextChanged;
            // 
            // textBoxAmount
            // 
            textBoxAmount.Location = new Point(93, 99);
            textBoxAmount.Name = "textBoxAmount";
            textBoxAmount.Size = new Size(100, 23);
            textBoxAmount.TabIndex = 17;
            textBoxAmount.Text = "0";
            textBoxAmount.TextChanged += textBoxAmount_TextChanged;
            // 
            // textBoxName
            // 
            textBoxName.Location = new Point(12, 60);
            textBoxName.Name = "textBoxName";
            textBoxName.Size = new Size(292, 23);
            textBoxName.TabIndex = 18;
            // 
            // textBoxCost
            // 
            textBoxCost.Location = new Point(522, 104);
            textBoxCost.Name = "textBoxCost";
            textBoxCost.Size = new Size(100, 23);
            textBoxCost.TabIndex = 20;
            textBoxCost.Text = "0";
            textBoxCost.TextChanged += textBoxCost_TextChanged;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(432, 107);
            label6.Name = "label6";
            label6.Size = new Size(90, 15);
            label6.TabIndex = 19;
            label6.Text = "Цена продажи:";
            // 
            // FormAdd
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(656, 217);
            Controls.Add(textBoxCost);
            Controls.Add(label6);
            Controls.Add(textBoxName);
            Controls.Add(textBoxAmount);
            Controls.Add(textBoxPricecost);
            Controls.Add(textBoxSum);
            Controls.Add(buttonCancel);
            Controls.Add(buttonAdd);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "FormAdd";
            Text = "CloudStore: Добавить товар";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Button buttonAdd;
        private Button buttonCancel;
        private TextBox textBoxSum;
        private TextBox textBoxPricecost;
        private TextBox textBoxAmount;
        private TextBox textBoxName;
        private TextBox textBoxCost;
        private Label label6;
    }
}