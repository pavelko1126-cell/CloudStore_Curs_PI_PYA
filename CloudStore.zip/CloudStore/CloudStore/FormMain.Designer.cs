﻿namespace CloudStore
{
    partial class FormMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            listViewProducts = new ListView();
            textBoxPrice = new TextBox();
            label5 = new Label();
            label4 = new Label();
            buttonAdd = new Button();
            label1 = new Label();
            buttonSell = new Button();
            buttonProfile = new Button();
            buttonExit = new Button();
            textBoxCostprice = new TextBox();
            textBoxAmount = new TextBox();
            textBoxSum = new TextBox();
            label2 = new Label();
            label3 = new Label();
            label6 = new Label();
            textBoxName = new TextBox();
            SuspendLayout();
            // 
            // listViewProducts
            // 
            listViewProducts.Location = new Point(219, 29);
            listViewProducts.Name = "listViewProducts";
            listViewProducts.Size = new Size(344, 355);
            listViewProducts.TabIndex = 41;
            listViewProducts.UseCompatibleStateImageBehavior = false;
            listViewProducts.View = View.List;
            listViewProducts.SelectedIndexChanged += listViewProducts_SelectedIndexChanged;
            // 
            // textBoxPrice
            // 
            textBoxPrice.Location = new Point(672, 121);
            textBoxPrice.Name = "textBoxPrice";
            textBoxPrice.ReadOnly = true;
            textBoxPrice.Size = new Size(118, 23);
            textBoxPrice.TabIndex = 29;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(602, 124);
            label5.Name = "label5";
            label5.Size = new Size(35, 15);
            label5.TabIndex = 28;
            label5.Text = "Цена";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(602, 168);
            label4.Name = "label4";
            label4.Size = new Size(48, 15);
            label4.TabIndex = 26;
            label4.Text = "Себест.";
            // 
            // buttonAdd
            // 
            buttonAdd.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 204);
            buttonAdd.Location = new Point(12, 72);
            buttonAdd.Name = "buttonAdd";
            buttonAdd.Size = new Size(176, 61);
            buttonAdd.TabIndex = 25;
            buttonAdd.Text = "Добавить товар";
            buttonAdd.UseVisualStyleBackColor = true;
            buttonAdd.Click += button1_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Arial", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 204);
            label1.Location = new Point(12, 29);
            label1.Name = "label1";
            label1.Size = new Size(114, 24);
            label1.TabIndex = 20;
            label1.Text = "CloudStore";
            // 
            // buttonSell
            // 
            buttonSell.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 204);
            buttonSell.Location = new Point(12, 150);
            buttonSell.Name = "buttonSell";
            buttonSell.Size = new Size(176, 61);
            buttonSell.TabIndex = 30;
            buttonSell.Text = "Продажи";
            buttonSell.UseVisualStyleBackColor = true;
            buttonSell.Click += buttonSell_Click;
            // 
            // buttonProfile
            // 
            buttonProfile.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 204);
            buttonProfile.Location = new Point(12, 237);
            buttonProfile.Name = "buttonProfile";
            buttonProfile.Size = new Size(176, 61);
            buttonProfile.TabIndex = 31;
            buttonProfile.Text = "Профиль";
            buttonProfile.UseVisualStyleBackColor = true;
            buttonProfile.Click += buttonProfile_Click;
            // 
            // buttonExit
            // 
            buttonExit.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 204);
            buttonExit.Location = new Point(12, 324);
            buttonExit.Name = "buttonExit";
            buttonExit.Size = new Size(176, 61);
            buttonExit.TabIndex = 32;
            buttonExit.Text = "Выйти";
            buttonExit.UseVisualStyleBackColor = true;
            buttonExit.Click += buttonExit_Click;
            // 
            // textBoxCostprice
            // 
            textBoxCostprice.Location = new Point(672, 160);
            textBoxCostprice.Name = "textBoxCostprice";
            textBoxCostprice.ReadOnly = true;
            textBoxCostprice.Size = new Size(118, 23);
            textBoxCostprice.TabIndex = 34;
            // 
            // textBoxAmount
            // 
            textBoxAmount.Location = new Point(672, 205);
            textBoxAmount.Name = "textBoxAmount";
            textBoxAmount.ReadOnly = true;
            textBoxAmount.Size = new Size(118, 23);
            textBoxAmount.TabIndex = 38;
            // 
            // textBoxSum
            // 
            textBoxSum.Location = new Point(672, 247);
            textBoxSum.Name = "textBoxSum";
            textBoxSum.ReadOnly = true;
            textBoxSum.Size = new Size(118, 23);
            textBoxSum.TabIndex = 37;
            textBoxSum.TextChanged += textBoxSum_TextChanged;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(602, 213);
            label2.Name = "label2";
            label2.Size = new Size(51, 15);
            label2.TabIndex = 36;
            label2.Text = "Остаток";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(602, 255);
            label3.Name = "label3";
            label3.Size = new Size(45, 15);
            label3.TabIndex = 35;
            label3.Text = "Сумма";
            // 
            // label6
            // 
            label6.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            label6.AutoSize = true;
            label6.Font = new Font("Arial", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 204);
            label6.Location = new Point(672, 29);
            label6.Name = "label6";
            label6.Size = new Size(66, 24);
            label6.TabIndex = 39;
            label6.Text = "Товар";
            label6.TextAlign = ContentAlignment.TopCenter;
            label6.Click += label6_Click;
            // 
            // textBoxName
            // 
            textBoxName.Location = new Point(602, 72);
            textBoxName.Name = "textBoxName";
            textBoxName.ReadOnly = true;
            textBoxName.Size = new Size(188, 23);
            textBoxName.TabIndex = 40;
            // 
            // FormMain
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(827, 396);
            Controls.Add(listViewProducts);
            Controls.Add(textBoxName);
            Controls.Add(label6);
            Controls.Add(textBoxAmount);
            Controls.Add(textBoxSum);
            Controls.Add(label2);
            Controls.Add(label3);
            Controls.Add(textBoxCostprice);
            Controls.Add(buttonExit);
            Controls.Add(buttonProfile);
            Controls.Add(buttonSell);
            Controls.Add(textBoxPrice);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(buttonAdd);
            Controls.Add(label1);
            Name = "FormMain";
            Text = "CloudStore";
            Load += Form3_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private TextBox textBoxPrice;
        private Label label5;
        private Label label4;
        private Button buttonAdd;
        private Label label1;
        private Button buttonSell;
        private Button buttonProfile;
        private Button buttonExit;
        private TextBox textBoxCostprice;
        private TextBox textBoxAmount;
        private TextBox textBoxSum;
        private Label label2;
        private Label label3;
        private Label label6;
        private TextBox textBoxName;
        public static ListView listViewProducts;
    }
}