﻿namespace CloudStore
{
    public partial class FormAdd : Form
    {
        public FormAdd()
        {
            InitializeComponent();
        }

        private void buttonCancel_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void textBoxAmount_TextChanged(object sender, EventArgs e)
        {
            try
            {
                Convert.ToInt32(textBoxAmount.Text);
            }
            catch
            {
                textBoxAmount.Undo();
                textBoxAmount.ClearUndo();
            }
            finally
            {
                textBoxSum.Text = Convert.ToString(Convert.ToInt32(textBoxAmount.Text) * Convert.ToInt32(textBoxPricecost.Text));
            }
        }

        private void textBoxPricecost_TextChanged(object sender, EventArgs e)
        {
            try
            {
                Convert.ToInt32(textBoxPricecost.Text);
            }
            catch
            {
                textBoxPricecost.Undo();
                textBoxPricecost.ClearUndo();
            }
            finally
            {
                textBoxSum.Text = Convert.ToString(Convert.ToInt32(textBoxAmount.Text) * Convert.ToInt32(textBoxPricecost.Text));
            }
        }

        private void buttonAdd_Click(object sender, EventArgs e)
        {
            if (textBoxName.Text == null)
            {
                textBoxName.Text = "Товар";
            }
            FormMain.products.Add(new product(textBoxName.Text, Convert.ToInt32(textBoxAmount.Text), Convert.ToInt32(textBoxCost.Text), Convert.ToInt32(textBoxPricecost.Text)));
            FormMain.listViewProducts.Items.Add(textBoxName.Text);
            Close();
        }

        private void textBoxCost_TextChanged(object sender, EventArgs e)
        {
            try
            {
                Convert.ToInt32(textBoxCost.Text);
            }
            catch
            {
                textBoxCost.Undo();
                textBoxCost.ClearUndo();
            }
        }
    }
}
