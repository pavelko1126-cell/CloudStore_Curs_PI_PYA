﻿namespace CloudStore
{
    partial class FormSell
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            textBoxAmount = new TextBox();
            textBoxPricecost = new TextBox();
            textBoxSumDiscount = new TextBox();
            buttonCancel = new Button();
            buttonSell = new Button();
            label5 = new Label();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            comboBoxName = new ComboBox();
            textBoxSellAmount = new TextBox();
            label6 = new Label();
            textBoxCost = new TextBox();
            label7 = new Label();
            textBoxDiscount = new TextBox();
            label8 = new Label();
            label9 = new Label();
            textBoxSum = new TextBox();
            label10 = new Label();
            textBoxSumAfter = new TextBox();
            label11 = new Label();
            SuspendLayout();
            // 
            // textBoxAmount
            // 
            textBoxAmount.Location = new Point(139, 103);
            textBoxAmount.Name = "textBoxAmount";
            textBoxAmount.ReadOnly = true;
            textBoxAmount.Size = new Size(100, 23);
            textBoxAmount.TabIndex = 28;
            // 
            // textBoxPricecost
            // 
            textBoxPricecost.Location = new Point(346, 103);
            textBoxPricecost.Name = "textBoxPricecost";
            textBoxPricecost.ReadOnly = true;
            textBoxPricecost.Size = new Size(100, 23);
            textBoxPricecost.TabIndex = 27;
            // 
            // textBoxSumDiscount
            // 
            textBoxSumDiscount.Location = new Point(110, 305);
            textBoxSumDiscount.Name = "textBoxSumDiscount";
            textBoxSumDiscount.ReadOnly = true;
            textBoxSumDiscount.Size = new Size(95, 23);
            textBoxSumDiscount.TabIndex = 26;
            // 
            // buttonCancel
            // 
            buttonCancel.Location = new Point(159, 347);
            buttonCancel.Name = "buttonCancel";
            buttonCancel.Size = new Size(75, 23);
            buttonCancel.TabIndex = 25;
            buttonCancel.Text = "Отменить";
            buttonCancel.UseVisualStyleBackColor = true;
            buttonCancel.Click += buttonCancel_Click;
            // 
            // buttonSell
            // 
            buttonSell.Location = new Point(12, 347);
            buttonSell.Name = "buttonSell";
            buttonSell.Size = new Size(118, 23);
            buttonSell.TabIndex = 24;
            buttonSell.Text = "Продать";
            buttonSell.UseVisualStyleBackColor = true;
            buttonSell.Click += buttonSell_Click;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(12, 106);
            label5.Name = "label5";
            label5.Size = new Size(125, 15);
            label5.TabIndex = 23;
            label5.Text = "Текущее количество:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(256, 106);
            label4.Name = "label4";
            label4.Size = new Size(84, 15);
            label4.TabIndex = 22;
            label4.Text = "Цена закупки:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(12, 308);
            label3.Name = "label3";
            label3.Size = new Size(92, 15);
            label3.TabIndex = 21;
            label3.Text = "Сумма  скидки:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(12, 46);
            label2.Name = "label2";
            label2.Size = new Size(90, 15);
            label2.TabIndex = 20;
            label2.Text = "Наименование";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Arial", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 204);
            label1.Location = new Point(170, 19);
            label1.Name = "label1";
            label1.Size = new Size(97, 24);
            label1.TabIndex = 19;
            label1.Text = "Продажа";
            // 
            // comboBoxName
            // 
            comboBoxName.FormattingEnabled = true;
            comboBoxName.Location = new Point(12, 64);
            comboBoxName.Name = "comboBoxName";
            comboBoxName.Size = new Size(157, 23);
            comboBoxName.TabIndex = 29;
            comboBoxName.SelectedIndexChanged += comboBoxName_SelectedIndexChanged;
            // 
            // textBoxSellAmount
            // 
            textBoxSellAmount.Location = new Point(93, 143);
            textBoxSellAmount.Name = "textBoxSellAmount";
            textBoxSellAmount.Size = new Size(100, 23);
            textBoxSellAmount.TabIndex = 31;
            textBoxSellAmount.Text = "0";
            textBoxSellAmount.TextChanged += textBoxSellAmount_TextChanged;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(12, 146);
            label6.Name = "label6";
            label6.Size = new Size(75, 15);
            label6.TabIndex = 30;
            label6.Text = "Количество:";
            // 
            // textBoxCost
            // 
            textBoxCost.Location = new Point(102, 182);
            textBoxCost.Name = "textBoxCost";
            textBoxCost.ReadOnly = true;
            textBoxCost.Size = new Size(100, 23);
            textBoxCost.TabIndex = 33;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(12, 185);
            label7.Name = "label7";
            label7.Size = new Size(90, 15);
            label7.TabIndex = 32;
            label7.Text = "Цена продажи:";
            // 
            // textBoxDiscount
            // 
            textBoxDiscount.Location = new Point(273, 182);
            textBoxDiscount.Name = "textBoxDiscount";
            textBoxDiscount.Size = new Size(100, 23);
            textBoxDiscount.TabIndex = 35;
            textBoxDiscount.Text = "0";
            textBoxDiscount.TextChanged += textBoxDiscount_TextChanged;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(218, 185);
            label8.Name = "label8";
            label8.Size = new Size(49, 15);
            label8.TabIndex = 34;
            label8.Text = "Скидка:";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(379, 185);
            label9.Name = "label9";
            label9.Size = new Size(17, 15);
            label9.TabIndex = 36;
            label9.Text = "%";
            // 
            // textBoxSum
            // 
            textBoxSum.Location = new Point(69, 219);
            textBoxSum.Name = "textBoxSum";
            textBoxSum.ReadOnly = true;
            textBoxSum.Size = new Size(100, 23);
            textBoxSum.TabIndex = 38;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(12, 222);
            label10.Name = "label10";
            label10.Size = new Size(48, 15);
            label10.TabIndex = 37;
            label10.Text = "Сумма:";
            // 
            // textBoxSumAfter
            // 
            textBoxSumAfter.Location = new Point(159, 262);
            textBoxSumAfter.Name = "textBoxSumAfter";
            textBoxSumAfter.ReadOnly = true;
            textBoxSumAfter.Size = new Size(100, 23);
            textBoxSumAfter.TabIndex = 40;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Location = new Point(12, 265);
            label11.Name = "label11";
            label11.Size = new Size(141, 15);
            label11.TabIndex = 39;
            label11.Text = "Сумма с учётом скидки:";
            // 
            // FormSell
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(465, 389);
            Controls.Add(textBoxSumAfter);
            Controls.Add(label11);
            Controls.Add(textBoxSum);
            Controls.Add(label10);
            Controls.Add(label9);
            Controls.Add(textBoxDiscount);
            Controls.Add(label8);
            Controls.Add(textBoxCost);
            Controls.Add(label7);
            Controls.Add(textBoxSellAmount);
            Controls.Add(label6);
            Controls.Add(comboBoxName);
            Controls.Add(textBoxAmount);
            Controls.Add(textBoxPricecost);
            Controls.Add(textBoxSumDiscount);
            Controls.Add(buttonCancel);
            Controls.Add(buttonSell);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "FormSell";
            Text = "CloudStore: Продажи";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox textBoxAmount;
        private TextBox textBoxPricecost;
        private TextBox textBoxSumDiscount;
        private Button buttonCancel;
        private Button buttonSell;
        private Label label5;
        private Label label4;
        private Label label3;
        private Label label2;
        private Label label1;
        private ComboBox comboBoxName;
        private TextBox textBoxSellAmount;
        private Label label6;
        private TextBox textBoxCost;
        private Label label7;
        private TextBox textBoxDiscount;
        private Label label8;
        private Label label9;
        private TextBox textBoxSum;
        private Label label10;
        private TextBox textBoxSumAfter;
        private Label label11;
    }
}