﻿namespace CloudStore
{
    public partial class FormMain : Form
    {
        public static List<product> products = new List<product>();
        public FormMain()
        {
            InitializeComponent();
        }

        public static void RefreshInfo()
        {
            listViewProducts.Items.Clear();
            foreach (product pr in products)
            {
                listViewProducts.Items.Add(pr.name);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            new FormAdd().ShowDialog();
        }

        private void Form3_Load(object sender, EventArgs e)
        {

        }

        private void buttonExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void buttonSell_Click(object sender, EventArgs e)
        {
            new FormSell().ShowDialog();
        }

        private void buttonProfile_Click(object sender, EventArgs e)
        {
            new FormProfile().ShowDialog();
        }

        private void textBoxSum_TextChanged(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void listViewProducts_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listViewProducts.SelectedItems.Count >0)
            {

                for (int i = 0; i < products.Count; i++)
                {
                    if (i == listViewProducts.SelectedIndices[0])
                    {
                        textBoxName.Text = products[i].name;
                        textBoxPrice.Text = Convert.ToString(products[i].price);
                        textBoxAmount.Text = Convert.ToString(products[i].amount);
                        textBoxCostprice.Text = Convert.ToString(products[i].costprice);
                        textBoxSum.Text = Convert.ToString(Convert.ToInt32(products[i].amount) * Convert.ToInt32(products[i].costprice));
                        break;
                    }
                }
            }
        }

    }
}