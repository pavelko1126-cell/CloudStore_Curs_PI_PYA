﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CloudStore
{
    public class product
    {
        public string name;
        public int amount;
        public int price;
        public int costprice;
        public product(string Name, int Amount, int Price, int CostPrice)
        {
            name = Name;
            amount = Amount;
            price = Price;
            costprice = CostPrice;
        }
    }
}
