﻿namespace CloudStore
{
    partial class FormEnter
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            textBoxLogin = new TextBox();
            label3 = new Label();
            textBoxPassword = new TextBox();
            buttonEnter = new Button();
            linkLabelReg = new LinkLabel();
            labelIncorrect = new Label();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Arial", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 204);
            label1.Location = new Point(182, 12);
            label1.Name = "label1";
            label1.Size = new Size(74, 32);
            label1.TabIndex = 0;
            label1.Text = "Вход";
            label1.Click += label1_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(14, 55);
            label2.Name = "label2";
            label2.Size = new Size(52, 20);
            label2.TabIndex = 1;
            label2.Text = "Логин";
            // 
            // textBoxLogin
            // 
            textBoxLogin.Location = new Point(14, 79);
            textBoxLogin.Margin = new Padding(3, 4, 3, 4);
            textBoxLogin.Name = "textBoxLogin";
            textBoxLogin.Size = new Size(420, 27);
            textBoxLogin.TabIndex = 2;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(14, 140);
            label3.Name = "label3";
            label3.Size = new Size(62, 20);
            label3.TabIndex = 3;
            label3.Text = "Пароль";
            // 
            // textBoxPassword
            // 
            textBoxPassword.Location = new Point(14, 164);
            textBoxPassword.Margin = new Padding(3, 4, 3, 4);
            textBoxPassword.Name = "textBoxPassword";
            textBoxPassword.Size = new Size(420, 27);
            textBoxPassword.TabIndex = 4;
            // 
            // buttonEnter
            // 
            buttonEnter.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 204);
            buttonEnter.Location = new Point(115, 225);
            buttonEnter.Margin = new Padding(3, 4, 3, 4);
            buttonEnter.Name = "buttonEnter";
            buttonEnter.Size = new Size(201, 47);
            buttonEnter.TabIndex = 5;
            buttonEnter.Text = "Войти";
            buttonEnter.UseVisualStyleBackColor = true;
            buttonEnter.Click += buttonEnter_Click;
            // 
            // linkLabelReg
            // 
            linkLabelReg.AutoSize = true;
            linkLabelReg.LinkColor = Color.FromArgb(0, 0, 64);
            linkLabelReg.Location = new Point(171, 276);
            linkLabelReg.Name = "linkLabelReg";
            linkLabelReg.Size = new Size(96, 20);
            linkLabelReg.TabIndex = 6;
            linkLabelReg.TabStop = true;
            linkLabelReg.Text = "Регистрация";
            linkLabelReg.LinkClicked += linkLabelReg_LinkClicked;
            // 
            // labelIncorrect
            // 
            labelIncorrect.AutoSize = true;
            labelIncorrect.ForeColor = Color.Red;
            labelIncorrect.Location = new Point(16, 205);
            labelIncorrect.Name = "labelIncorrect";
            labelIncorrect.Size = new Size(368, 20);
            labelIncorrect.TabIndex = 7;
            labelIncorrect.Text = "Неверный логин и/или пароль. Попробуйте снова.";
            // 
            // FormEnter
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(448, 308);
            Controls.Add(labelIncorrect);
            Controls.Add(linkLabelReg);
            Controls.Add(buttonEnter);
            Controls.Add(textBoxPassword);
            Controls.Add(label3);
            Controls.Add(textBoxLogin);
            Controls.Add(label2);
            Controls.Add(label1);
            Margin = new Padding(3, 4, 3, 4);
            Name = "FormEnter";
            Text = "CloudStore: Вход";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private TextBox textBoxLogin;
        private Label label3;
        private TextBox textBoxPassword;
        private Button buttonEnter;
        private LinkLabel linkLabelReg;
        private Label labelIncorrect;
    }
}
