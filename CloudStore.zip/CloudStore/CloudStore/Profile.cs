﻿namespace CloudStore
{
    static class profile
    {
        public static string name;
        public static string surname;
        public static string email;
        public static string password;
        public static string login;
        public static void Register(string Name, string Surname, string Email, string Password, string Login)
        {
            name = Name;
            surname = Surname;
            email = Email;
            password = Password;
            login = Login;
        }
    }

}
